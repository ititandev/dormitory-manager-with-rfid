TODO:

Create Examples:
- Read more stuff than the serial number
- Write to a card
- Do some ethernet stuff (with an ethernet module) 
